import { Component } from '@angular/core';
import { single } from 'rxjs/operators';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'samplee';
  render: boolean;
  ren = true

name
password








saveEmployee(empform: NgForm)
{
  console.log("Hello")
  this.name = empform.value.Name
  console.log(this.name)
  this.password = empform.value.Password
  console.log(this.password)

  this.render = true;

  this.ren = false;

}










}


